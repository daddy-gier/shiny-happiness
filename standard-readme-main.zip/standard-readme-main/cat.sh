#! /bin/bash

cat spec.md
