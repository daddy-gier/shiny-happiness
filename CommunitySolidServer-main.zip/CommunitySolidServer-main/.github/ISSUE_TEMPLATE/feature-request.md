---
name: "➕ Feature request"
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

#### Feature description

<!--In case you want to start a discussion about an idea, discussions are better suited for this https://github.com/CommunitySolidServer/CommunitySolidServer/discussions -->
<!--A clear and concise description of what you want to happen.-->
