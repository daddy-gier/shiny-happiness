---
name: "\U0001F41B Bug report"
about: If something is not working as expected or crashes
title: ''
labels: ''
assignees: ''

---

#### Environment

- Server version: *Output of `community-solid-server --version` for a
  global or `npx community-solid-server --version` for a local installation*
- Node.js version: *Output of `node -v`*
- npm version: *Output of `npm -v`*

#### Description
<!-- Please describe the exact problem as clearly as possible. Provide any error messages thrown. -->
