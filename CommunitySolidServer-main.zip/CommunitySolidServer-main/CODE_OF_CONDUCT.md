# Code of Conduct

For our Code of Conduct, we follow and adhere to the Solid [Code of Conduct](https://github.com/solid/process/blob/main/code-of-conduct.md),
but with a different Committee, which should be contacted in the case of violations.

The Committee consists of the following people:

* Joachim Van Herwegen <joachim.vanherwegen@ugent.be>
* Ruben Verborgh <ruben.verborgh@ugent.be>
