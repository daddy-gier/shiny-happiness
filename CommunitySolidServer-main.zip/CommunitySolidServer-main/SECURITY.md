# Security Policy

## Reporting a Vulnerability

To report and discuss security vulnerabilities go to <https://github.com/CommunitySolidServer/CommunitySolidServer/security/advisories>
