import type { Representation } from './Representation';

/**
 * Represents the changes needed for a PATCH request.
 */
export interface Patch extends Representation {
}
