# Music
## Music Theory
  * [How Music Works with Howard Goodall](https://www.youtube.com/watch?v=PnbOWi6f_IM&list=PLC93AAAF9FBD76358)
  * [Music Theory](musictheory.net)

## Guitar
  * [Music Theory for Guitar with Brett Sanders](https://www.youtube.com/watch?v=Mp8c2pvB0W8&list=PL837E441F8EA7C109)
  * [The Guitar Handbook by Isaac Guillory and Ralph Denyer](https://www.amazon.com/The-Guitar-Handbook-Ralph-Denyer/dp/0679742751)
