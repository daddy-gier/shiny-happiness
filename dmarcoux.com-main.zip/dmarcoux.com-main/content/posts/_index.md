+++
paginate_by = 7
title = "Posts"
sort_by = "date"
template = "posts.html"

insert_anchor_links = "heading"
+++
