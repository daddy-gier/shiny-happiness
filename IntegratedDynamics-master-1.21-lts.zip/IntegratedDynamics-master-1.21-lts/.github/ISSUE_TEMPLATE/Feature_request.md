---
name: "➕ Feature request"
about: Suggest an idea for this project

---

<!--Thanks in advance for this issue, you're awesome!-->
<!--Please fill in the following template and make sure your title clear and concisely summarizes the issue.-->

#### Issue type:

- :heavy_plus_sign: Feature request <!--Don't change this issue type!-->

____

#### Short description:

<!--A clear and concise description of what you want to happen.-->
